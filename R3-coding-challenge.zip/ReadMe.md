###READ ME
* Uses Java 8
* Uses maven to build and run application.
* Change oxoinput to desired oxo grid setting (3x3).
* Use mvn clean compile exec:java to run the application



